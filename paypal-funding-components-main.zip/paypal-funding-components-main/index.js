/* @flow */

// $FlowFixMe
module.exports = require('./server'); // eslint-disable-line import/no-commonjs

/* @flow */

export const TYPES = true;

/* @flow */

export const QUERY_PARAM = {
    DOMAIN:          'domain',
    CLIENT_ID:       'client-id',
    SDK_META:        'sdkMeta',
    FUNDING_SOURCES: 'funding-sources',
    EXPIRY:          'expiry'
};

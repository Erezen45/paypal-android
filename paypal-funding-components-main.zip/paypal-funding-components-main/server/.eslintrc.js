/* @flow */
/* eslint import/no-commonjs: off */

module.exports = {
    'extends': '../.eslintrc.js',

    'rules': {
        'no-restricted-globals': 'off',
        'promise/no-native':     'off',
        'compat/compat':         'off'
    }
};

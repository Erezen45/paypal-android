/* @flow */
/* eslint import/no-commonjs: off */

module.exports = {
    extends: '@krakenjs/grumbler-scripts/config/.babelrc-node'
};
